package controllers

type UserController struct{}

func (c UserController) List() {

}

func (c UserController) Show() {

}

func (c UserController) Create() {

}

func (c UserController) Edit() {

}

func (c UserController) Destroy() {

}
