package responders

import (
	"github.com/thedevsaddam/renderer"
)

var render = renderer.New()
